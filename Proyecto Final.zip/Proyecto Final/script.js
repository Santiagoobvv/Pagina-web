let carrito = JSON.parse(localStorage.getItem('carrito')) || [];

const listaProductos = document.querySelector('#lista-1');
const contenedorCarrito = document.querySelector('#lista-carrito tbody');
const contadorCarrito = document.querySelector('#contador-carrito');
const totalCarrito = document.querySelector('#total-carrito');
const vaciarCarritoBtn = document.querySelector('#vaciar-carrito');

document.addEventListener('DOMContentLoaded', () => {
    actualizarCarrito();
});

if (listaProductos) {
    listaProductos.addEventListener('click', agregarProducto);
}

if (vaciarCarritoBtn) {
    vaciarCarritoBtn.addEventListener('click', vaciarCarrito);
}

function agregarProducto(e) {
    e.preventDefault();
    if (e.target.classList.contains('agregar-carrito')) {
        const producto = e.target.closest('.product');
        leerDatosProducto(producto);
    }
}

function leerDatosProducto(producto) {
    const id = producto.querySelector('a').getAttribute('data-id');
    const nombre = producto.querySelector('h3').textContent;
    const precio = producto.querySelector('.precio').textContent;
    const imagen = producto.querySelector('img').src;
    const cantidadInput = producto.querySelector('.cantidad-producto');
    const cantidad = parseInt(cantidadInput.value);

    const productoExistente = carrito.find(item => item.id === id);

    if (productoExistente) {
        productoExistente.cantidad += cantidad;
    } else {
        carrito.push({ id, nombre, precio, imagen, cantidad });
    }

    guardarCarrito();
    actualizarCarrito();
}

function actualizarCarrito() {
    limpiarCarritoHTML();
    let total = 0;
    let contador = 0;

    carrito.forEach(producto => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><img src="${producto.imagen}" width="50"></td>
            <td>${producto.nombre}</td>
            <td>${producto.precio} x ${producto.cantidad}</td>
            <td><a href="#" class="borrar-producto" data-id="${producto.id}">X</a></td>
        `;
        contenedorCarrito.appendChild(row);

        const precioNumerico = parseFloat(producto.precio.replace('$', '').replace(',', ''));
        total += precioNumerico * producto.cantidad;
        contador += producto.cantidad;
    });

    totalCarrito.textContent = `$${total.toLocaleString()}`;
    contadorCarrito.textContent = contador;

    document.querySelectorAll('.borrar-producto').forEach(btn => {
        btn.addEventListener('click', eliminarProducto);
    });
}

function eliminarProducto(e) {
    e.preventDefault();
    const id = e.target.getAttribute('data-id');
    carrito = carrito.filter(producto => producto.id !== id);
    guardarCarrito();
    actualizarCarrito();
}

function vaciarCarrito(e) {
    e.preventDefault();
    carrito = [];
    guardarCarrito();
    actualizarCarrito();
}

function limpiarCarritoHTML() {
    contenedorCarrito.innerHTML = '';
}

function guardarCarrito() {
    localStorage.setItem('carrito', JSON.stringify(carrito));
}



    const images = document.querySelectorAll('.store');

    images.forEach(img => {
        img.addEventListener('click', (e) => {
            // Elimina la clase 'expanded' de todas las imágenes
            images.forEach(i => i.classList.remove('expanded'));

            // Detiene la propagación para que no se cierre de inmediato
            e.stopPropagation();

            // Añade la clase solo a la imagen clickeada
            img.classList.add('expanded');
        });
    });

    // Cuando se hace clic en cualquier parte del documento fuera de una imagen
    document.addEventListener('click', () => {
        images.forEach(i => i.classList.remove('expanded'));
    });


      const imagess = document.querySelectorAll('.store2');

    imagess.forEach(img => {
        img.addEventListener('click', (e) => {
            // Elimina la clase 'expanded' de todas las imágenes
            imagess.forEach(i => i.classList.remove('expanded'));

            // Detiene la propagación para que no se cierre de inmediato
            e.stopPropagation();

            // Añade la clase solo a la imagen clickeada
            img.classList.add('expanded');
        });
    });

    // Cuando se hace clic fuera de una imagen, se colapsan todas
    document.addEventListener('click', () => {
        imagess.forEach(i => i.classList.remove('expanded'));
    });